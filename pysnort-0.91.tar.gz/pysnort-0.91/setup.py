#!/usr/bin/env python

from distutils.core import setup
setup(name="pysnort", 
version = "0.91", 
author = "Ignacio Vazquez",
author_email = "irvazquez@users.sourceforge.net",
url = "http://pysnort.sourceforge.net",
description = "Snort-IDS Library",
py_modules=["pysnort"])



